package main.java.entities;
import java.awt.Image;
import java.util.Random;
import main.java.utils.Direction;

public class Ghost extends Entity {
    private static final Random random = new Random();
    private Image normalImage;
    private Image scaredImage;
    private boolean isScared = false;
    
    public Ghost(Image normalImage, Image scaredImage, int x, int y, int width, int height) {
        super(normalImage, x, y, width, height);
        this.normalImage = normalImage;
        this.scaredImage = scaredImage;
    }
    
    public void changeDirectionRandomly(int tileSize) {
        Direction[] directions = Direction.values();
        direction = directions[random.nextInt(directions.length)];
        updateVelocity(tileSize);
    }
    
    private void updateVelocity(int tileSize) {
        int speed = isScared ? tileSize/6 : tileSize/4; // Slower when scared
        
        switch (direction) {
            case UP:
                velocityX = 0;
                velocityY = -speed;
                break;
            case DOWN:
                velocityX = 0;
                velocityY = speed;
                break;
            case LEFT:
                velocityX = -speed;
                velocityY = 0;
                break;
            case RIGHT:
                velocityX = speed;
                velocityY = 0;
                break;
        }
    }
    
    public void setScared(boolean scared) {
        this.isScared = scared;
        this.image = scared ? scaredImage : normalImage;
    }
    
    public boolean isScared() {
        return isScared;
    }
    
    @Override
    public void reset() {
        super.reset();
        setScared(false);
    }
}