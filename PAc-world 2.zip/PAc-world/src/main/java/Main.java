package main.java;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Pac-Man");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // Create menu panel
            JPanel menuPanel = new JPanel(new BorderLayout());
            menuPanel.setBackground(Color.BLACK);
            
            JLabel title = new JLabel("PAC-MAN", SwingConstants.CENTER);
            title.setFont(new Font("Arial", Font.BOLD, 48));
            title.setForeground(Color.YELLOW);
            
            JButton startButton = new JButton("START GAME");
            startButton.setFont(new Font("Arial", Font.BOLD, 24));
            startButton.setBackground(Color.BLACK);
            startButton.setForeground(Color.YELLOW);
            startButton.setFocusPainted(false);
            
            menuPanel.add(title, BorderLayout.CENTER);
            menuPanel.add(startButton, BorderLayout.SOUTH);
            
            // Create game panel (initially hidden)
            Game game = new Game();
            GamePanel gamePanel = new GamePanel(game);
            gamePanel.setVisible(false);
            
            frame.add(menuPanel);
            
            startButton.addActionListener(e -> {
                menuPanel.setVisible(false);
                frame.remove(menuPanel);
                frame.add(gamePanel);
                gamePanel.setVisible(true);
                gamePanel.requestFocusInWindow();
                game.start();
            });
            
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}