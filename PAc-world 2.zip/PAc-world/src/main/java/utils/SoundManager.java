package main.java.utils;

import javax.sound.sampled.*;
import java.io.File;

public class SoundManager {
    private Clip backgroundMusic;
    private boolean soundEnabled = true;
    
    public void playSound(String filename, boolean loop) {
        if (!soundEnabled) return;
        
        try {
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(
                new File(getClass().getResource("/sounds/" + filename).toURI()));
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            if (loop) {
                clip.loop(Clip.LOOP_CONTINUOUSLY);
                backgroundMusic = clip;
            }
            clip.start();
        } catch (Exception e) {
            System.err.println("Error playing sound: " + e.getMessage());
        }
    }
    
    public void stopBackgroundMusic() {
        if (backgroundMusic != null) {
            backgroundMusic.stop();
        }
    }
    
    public void toggleSound() {
        soundEnabled = !soundEnabled;
        if (!soundEnabled) {
            stopBackgroundMusic();
        } else {
            playSound("doraemon.wav", true);
        }
    }
}