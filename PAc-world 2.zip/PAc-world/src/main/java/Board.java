package main.java;
import main.java.entities.*;
import main.java.utils.*;
import java.util.HashSet;
import java.awt.Image;

public class Board {
    private int rowCount = 21;
    private int columnCount = 19;
    private int tileSize = 32;
    private String[] tileMap;
    private HashSet<Wall> walls;
    private HashSet<Entity> foods;
    private HashSet<Ghost> ghosts;
    private int playerStartX, playerStartY;
    
    public Board(String[] tileMap) {
        this.tileMap = tileMap;
        this.walls = new HashSet<>();
        this.foods = new HashSet<>();
        this.ghosts = new HashSet<>();
    }
    
    public void loadMap(ImageManager imageManager) {
        walls.clear();
        foods.clear();
        ghosts.clear();
        
        Image scaredImage = imageManager.loadImage("/images/scaredGhost.png");
        
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < columnCount; c++) {
                char tileChar = tileMap[r].charAt(c);
                int x = c * tileSize;
                int y = r * tileSize;
                
                switch (tileChar) {
                    case 'X': // Wall
                        walls.add(new Wall(imageManager.loadImage("/images/wall.png"), x, y, tileSize, tileSize));
                        break;
                    case ' ': // Food
                        foods.add(new Food(null, x + 14, y + 14, 4, 4));
                        break;
                    case 'O': // Power pelle
                        foods.add(new Entity(imageManager.loadImage("/images/powerPellet.png"), x + 8, y + 8, 16, 16));
                        break;
                    case 'C': // Cherry
                        foods.add(new Entity(imageManager.loadImage("/images/cherry.png"), x + 4, y + 4, 24, 24));
                        break;
                    case 'P': // Player
                        playerStartX = x;
                        playerStartY = y;
                        break;
                    case 'b': // Blue Ghost
                        ghosts.add(new Ghost(
                            imageManager.loadImage("/images/blueGhost.png"),
                            scaredImage, x, y, tileSize, tileSize));
                        break;
                    case 'o': // Orange Ghost
                        ghosts.add(new Ghost(
                            imageManager.loadImage("/images/orangeGhost.png"),
                            scaredImage, x, y, tileSize, tileSize));
                        break;
                    case 'p': // Pink Ghost
                        ghosts.add(new Ghost(
                            imageManager.loadImage("/images/pinkGhost.png"),
                            scaredImage, x, y, tileSize, tileSize));
                        break;
                    case 'r': // Red Ghost
                        ghosts.add(new Ghost(
                            imageManager.loadImage("/images/redGhost.png"),
                            scaredImage, x, y, tileSize, tileSize));
                        break;
                }
            }
        }
    }
    
    // Getters
    public HashSet<Wall> getWalls() { return walls; }
    public HashSet<Entity> getFoods() { return foods; }
    public HashSet<Ghost> getGhosts() { return ghosts; }
    public int getTileSize() { return tileSize; }
    public int getBoardWidth() { return columnCount * tileSize; }
    public int getBoardHeight() { return rowCount * tileSize; }
    public int getPlayerStartX() { return playerStartX; }
    public int getPlayerStartY() { return playerStartY; }
}