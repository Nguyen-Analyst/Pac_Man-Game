
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel {
    private Game game;
    
    public GamePanel(Game game) {
        this.game = game;
        setPreferredSize(new Dimension(game.getBoard().getBoardWidth(), game.getBoard().getBoardHeight()));
        setBackground(Color.BLACK);
        
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                game.handleKeyPress(e.getKeyCode());
                repaint();
            }
        });
        
        setFocusable(true);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        game.render(g);
    }
}