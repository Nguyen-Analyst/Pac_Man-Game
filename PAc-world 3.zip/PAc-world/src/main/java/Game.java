import entities.*;
import utils.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Random;

public class Game implements ActionListener {
    private Board board;
    private Player player;
    private Timer gameLoop;
    private int score = 0;
    private int lives = 3;
    private boolean gameOver = false;
    private boolean paused = false;
    private SoundManager soundManager;
    private boolean powerPelletActive = false;
    private int powerPelletTimer = 0;
    private static final int POWER_PELLET_DURATION = 300; // 6 seconds at 50ms/tick
    
    public Game() {
        soundManager = new SoundManager();
        soundManager.playSound("begin.wav", false);
        soundManager.playSound("doraemon.wav", true);
        
        ImageManager imageManager = new ImageManager();
        
        String[] tileMap = {
            "XXXXXXXXXXXXXXXXXXX",
            "X        X        X",
            "X XX XXX X XXX XX X",
            "X                 X",
            "X XX X XXXXX X XX X",
            "X    X       X    X",
            "XXXX XXXX XXXX XXXX",
            "OOOX X       X XOOO",
            "XXXX X XXrXX X XXXX",
            "O       bpo       O",
            "XXXX X XXXXX X XXXX",
            "OOOX X       X XOOO",
            "XXXX X XXXXX X XXXX",
            "X        X        X",
            "X XX XXX X XXX XX X",
            "X  X     P     X  X",
            "XX X X XXXXX X X XX",
            "X    X   X   X    X",
            "X XXXXXX X XXXXXX X",
            "X                 X",
            "XXXXXXXXXXXXXXXXXXX" 
        };

        board = new Board(tileMap);
        board.loadMap(imageManager);
        
        // Load player animations (assuming you have pacmanRight_1.png, pacmanRight_2.png, etc.)
        Image[] rightFrames = {
            imageManager.loadImage("/images/pacmanRight.png"),
        };
        Image[] upFrames = {
            imageManager.loadImage("/images/pacmanUp.png"),
        };
        Image[] downFrames = {
            imageManager.loadImage("/images/pacmanDown.png"),
        };
        Image[] leftFrames = {
            imageManager.loadImage("/images/pacmanLeft.png"),
        };
        
        player = new Player(
            rightFrames, upFrames, downFrames, leftFrames,
            board.getPlayerStartX(),
            board.getPlayerStartY(),
            board.getTileSize(),
            board.getTileSize()
        );
        
        // Initialize ghost directions
        for (Ghost ghost : board.getGhosts()) {
            ghost.changeDirectionRandomly(board.getTileSize());
        }
        
        gameLoop = new Timer(50, this);
    }
    
    public void start() {
        gameLoop.start();
    }
    
    public void render(Graphics g) {
        // Draw player
        player.updateAnimation();
        g.drawImage(player.getImage(), player.getX(), player.getY(), 
                   player.getWidth(), player.getHeight(), null);
        
        // Draw ghosts
        for (Ghost ghost : board.getGhosts()) {
            g.drawImage(ghost.getImage(), ghost.getX(), ghost.getY(), 
                       ghost.getWidth(), ghost.getHeight(), null);
        }
        
        // Draw walls
        for (Wall wall : board.getWalls()) {
            g.drawImage(wall.getImage(), wall.getX(), wall.getY(), 
                       wall.getWidth(), wall.getHeight(), null);
        }
        
        // Draw food
        g.setColor(Color.WHITE);
        for (Entity food : board.getFoods()) {
            if (food.getImage() == null) { // Regular food pellet
                g.fillRect(food.getX(), food.getY(), food.getWidth(), food.getHeight());
            } else { // Power pellet or cherry
                g.drawImage(food.getImage(), food.getX(), food.getY(), 
                           food.getWidth(), food.getHeight(), null);
            }
        }
        
        // Draw score and lives
        g.setFont(new Font("Arial", Font.BOLD, 18));
        if (gameOver) {
            g.setColor(Color.RED);
            g.drawString("GAME OVER - Score: " + score, board.getTileSize(), board.getTileSize());
            g.drawString("Press any key to restart", board.getTileSize(), board.getTileSize() + 30);
        } else if (paused) {
            g.setColor(Color.YELLOW);
            g.drawString("PAUSED", board.getBoardWidth()/2 - 30, board.getBoardHeight()/2);
        } else {
            g.setColor(Color.YELLOW);
            g.drawString("Score: " + score, 20, 20);
            g.drawString("Lives: " + lives, board.getBoardWidth() - 80, 20);
            
            // Draw power pellet timer if active
            if (powerPelletActive) {
                int remainingTime = powerPelletTimer / 10;
                g.drawString("Power: " + remainingTime + "s", board.getBoardWidth()/2 - 30, 20);
            }
        }
    }
    
    public void update() {
        if (gameOver || paused) return;

        if (powerPelletActive) {
            powerPelletTimer--;
            if (powerPelletTimer <= 0) {
                powerPelletActive = false;
                resetGhostImages();
            }
        }

        // Player movement
        player.updatePosition();
        
        // Wall collision for player
        for (Wall wall : board.getWalls()) {
            if (player.collidesWith(wall)) {
                player.setX(player.getX() - player.getVelocityX());
                player.setY(player.getY() - player.getVelocityY());
                break;
            }
        }
        
        // Screen wrapping (tunnels)
        if (player.getX() < -player.getWidth()) {
            player.setX(board.getBoardWidth());
        } else if (player.getX() > board.getBoardWidth()) {
            player.setX(-player.getWidth());
        }
        
        // Ghost collisions and movement
        for (Ghost ghost : board.getGhosts()) {
            if (ghost.collidesWith(player)) {
                if (powerPelletActive && !ghost.isScared()) {
                    soundManager.playSound("pacman_eatghost.wav", false);
                    ghost.reset();
                    score += 200;
                } else if (!ghost.isScared()) {
                    soundManager.playSound("pacman_death.wav", false);
                    lives--;
                    if (lives == 0) {
                        gameOver = true;
                        soundManager.stopBackgroundMusic();
                        return;
                    }
                    resetPositions();
                }
            }
            
            // Special ghost behavior at row 9
            if (ghost.getY() == board.getTileSize()*9 && 
                ghost.getDirection() != Direction.UP && 
                ghost.getDirection() != Direction.DOWN) {
                ghost.setDirection(Direction.UP);
                ghost.changeDirectionRandomly(board.getTileSize());
            }
            
            ghost.updatePosition();
            
            // Ghost-wall collision
            for (Wall wall : board.getWalls()) {
                if (ghost.collidesWith(wall) || 
                    ghost.getX() <= 0 || 
                    ghost.getX() + ghost.getWidth() >= board.getBoardWidth()) {
                    ghost.setX(ghost.getX() - ghost.getVelocityX());
                    ghost.setY(ghost.getY() - ghost.getVelocityY());
                    ghost.changeDirectionRandomly(board.getTileSize());
                }
            }
            
            // Ghost screen wrapping
            if (ghost.getX() < -ghost.getWidth()) {
                ghost.setX(board.getBoardWidth());
            } else if (ghost.getX() > board.getBoardWidth()) {
                ghost.setX(-ghost.getWidth());
            }
        }
        
        // Food collection
        Entity foodEaten = null;
        for (Entity food : board.getFoods()) {
            if (player.collidesWith(food)) {
                foodEaten = food;
                if (food.getImage() != null && food.getImage().toString().contains("powerPellet")) {
                    activatePowerPellet();
                    score += 50;
                } else if (food.getImage() != null && food.getImage().toString().contains("cherry")) {
                    score += 100;
                } else {
                    score += 10;
                }
            }
        }
        board.getFoods().remove(foodEaten);
        
        // Level completion
        if (board.getFoods().isEmpty()) {
            soundManager.playSound("win.wav", false);
            board.loadMap(new ImageManager());
            resetPositions();
        }
    }
    
    private void activatePowerPellet() {
        powerPelletActive = true;
        powerPelletTimer = POWER_PELLET_DURATION;
        for (Ghost ghost : board.getGhosts()) {
            ghost.setScared(true);
        }
    }
    
    private void resetGhostImages() {
        for (Ghost ghost : board.getGhosts()) {
            ghost.setScared(false);
        }
    }
    
    private void resetPositions() {
        player.reset();
        player.setVelocityX(0);
        player.setVelocityY(0);
        for (Ghost ghost : board.getGhosts()) {
            ghost.reset();
            ghost.changeDirectionRandomly(board.getTileSize());
        }
    }
    
    public void handleKeyPress(int keyCode) {
        if (gameOver) {
            // Reset game
            board.loadMap(new ImageManager());
            resetPositions();
            lives = 3;
            score = 0;
            gameOver = false;
            powerPelletActive = false;
            soundManager.playSound("doraemon.wav", true);
            gameLoop.start();
            return;
        }
        
        if (keyCode == KeyEvent.VK_P) {
            paused = !paused;
            return;
        }
        
        if (paused) return;
        
        Direction newDirection = Direction.fromKeyCode(keyCode);
        player.updateDirection(newDirection, board.getTileSize());
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        update();
    }
    
    // Getters
    public Board getBoard() { return board; }
    public Player getPlayer() { return player; }
    public boolean isGameOver() { return gameOver; }
    public boolean isPaused() { return paused; }
}